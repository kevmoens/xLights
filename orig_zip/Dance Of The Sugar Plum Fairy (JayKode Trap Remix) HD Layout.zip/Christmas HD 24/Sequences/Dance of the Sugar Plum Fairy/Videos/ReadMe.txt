Get the files from the repo at:
\Dance of the Sugar Plum Fairy\Videos